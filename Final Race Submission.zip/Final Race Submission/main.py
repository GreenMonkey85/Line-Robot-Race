from machine import Pin, ADC, PWM
import time
import random
import utime
from time import sleep
import math

###############
#  CONSTANTS  #
###############

MAX_SPEED = 65535
SPEED_360 = 0.22125


# class Sensor:
#     def __init__(self, trigger, echo, number):
#         self.trigger = trigger
#         self.echo = echo
#         self.number = number
#         
#     def ultra(self):
#         signaloff = 0
#         signalon = 0
#         self.trigger.low()
#         utime.sleep_us(2)
#         self.trigger.high()
#         utime.sleep_us(5)
#         self.trigger.low()
#         while self.echo.value() == 0:
#             signaloff = utime.ticks_us()
# #             print("Echo = 0")
#         while self.echo.value() == 1:
#             signalon = utime.ticks_us()
# #             print("Echo = 1")
#         timepassed = signalon - signaloff
#         distance = (timepassed * 0.0343) / 2
#         print(f"The distance from object ", self.number, "is ", distance, "cm")
#         return distance
            
###############
#  IR SENSOR  #
###############
class ir_sensor_array():
    # CONSTRUCTOR #
    def __init__(self, left, center, right):
        self.left_pin = ADC(left)
        self.center_pin = ADC(center)
        self.right_pin = ADC(right)
        
    def read_values(self):
        # This method reads the values of all three IR sensors
        left_val = self.left_pin.read_u16()
        center_val = self.center_pin.read_u16()
        right_val = self.right_pin.read_u16()
        return left_val, center_val, right_val
    
###########
#  MOTOR  #
###########
    
class Motor():
    # CONSTRUCTOR
    def __init__(self, rightForward, rightReverse, leftForward, leftReverse):
        self.rightForward = rightForward
        self.rightReverse = rightReverse
        self.leftForward = leftForward
        self.leftReverse = leftReverse
        
        # Initialize frequency and speed
        rightForward.freq(100)
        rightReverse.freq(100)

        leftForward.freq(100)
        leftReverse.freq(100)

        rightForward.duty_u16(0)
        rightReverse.duty_u16(0)

        leftForward.duty_u16(0)
        leftReverse.duty_u16(0)
        
    def motorOff(self):
        '''turns the motor off'''
        self.rightForward.duty_u16(0)
        self.leftForward.duty_u16(0)
        self.rightReverse.duty_u16(0)
        self.leftReverse.duty_u16(0)
        
    def motorOn(self, direction, speed, frequency):
        '''
        This method turns the motor on and gives the desired
        direction, speed, and frequency to the motors
        '''
        # implement constants
        global MAX_SPEED, SPEED_360
        
        # set frequency to the desired frequency
        self.rightForward.freq(frequency)
        self.rightReverse.freq(frequency)
        self.leftForward.freq(frequency)
        self.leftReverse.freq(frequency)
        
        # fix the desired speed
        speed = speed * 0.01
        
        '''DIRECTIONS'''
            
        # FORWARD    
        if direction == 'f':
            self.rightReverse.duty_u16(0)
            self.leftReverse.duty_u16(0)
            self.rightForward.duty_u16(math.floor(MAX_SPEED * speed * 0.9))
            self.leftForward.duty_u16(math.floor(MAX_SPEED * speed))
        # REVERSE
        elif direction == 'r':
            self.rightForward.duty_u16(0)
            self.leftForward.duty_u16(0)
            self.rightReverse.duty_u16(math.floor(MAX_SPEED * speed))
            self.leftReverse.duty_u16(math.floor(MAX_SPEED * speed))
        # STOP AND TURN RIGHT
        elif direction == 'sr':
            self.rightForward.duty_u16(0)
            self.leftReverse.duty_u16(0)
            # right wheel goes backwards while left wheel goes forwards
            self.rightReverse.duty_u16(math.floor(MAX_SPEED * speed))
            self.leftForward.duty_u16(math.floor(MAX_SPEED * speed))
        # STOP AND TURN LEFT
        elif direction == 'sl':
            self.rightReverse.duty_u16(0)
            self.leftForward.duty_u16(0)
            # left wheel goes backwards while right wheel goes forwards
            self.rightForward.duty_u16(math.floor(MAX_SPEED * speed * 0.9))
            self.leftReverse.duty_u16(math.floor(MAX_SPEED * speed))
        # CIRCLE LEFT
        elif direction == 'cl':
            self.rightReverse.duty_u16(0)
            self.leftForward.duty_u16(0)
            self.leftReverse.duty_u16(0)
            # only right wheel goes forwards
            self.rightForward.duty_u16(math.floor(MAX_SPEED * speed * 0.9))
        # CIRCLE RIGHT
        elif direction == 'cr':
            self.rightReverse.duty_u16(0)
            self.rightForward.duty_u16(0)
            self.leftReverse.duty_u16(0)
            # only left wheel goes forwards
            self.leftForward.duty_u16(math.floor(MAX_SPEED * speed))

        

        
# def button_reader_thread():
#     global buttonPressed
#     while True:
#         if button.value() == 1:
#             print("Pressed!")
#             if buttonPressed:
#                 buttonPressed = False
#             else:            
#                 buttonPressed = True
#         sleep(0.1)
        
        
        





# create objects

motor1 = Motor(PWM(Pin(6)), PWM(Pin(7)), PWM(Pin(20)), PWM(Pin(19)))
# sensor1 = Sensor(Pin(14, Pin.OUT), Pin(15, Pin.IN), 1)    # unused sensor #    
ir_sensor_array1 = ir_sensor_array(28, 27, 26)
button = Pin(0, Pin.IN, Pin.PULL_DOWN)
global buttonPressed
buttonPressed = False

# used for testing VVV

# while True:
#     motor1.motorOn('f', 30, 100)


# Main Loop
while True:

    # read each IR values
    left, center, right = ir_sensor_array1.read_values()
    
    # button functions like a switch
    if button.value() == 1:
        print("Pressed!")
        if buttonPressed:
            buttonPressed = False
        else:            
            buttonPressed = True
        sleep(0.15)
    
    # if button is switched on
    if buttonPressed:

        # move forward if center IR sensor is on the line
        if center > 29500:
            motor1.motorOn('f', 30, 100)
        # move right if right IR sensor is over the line
        elif right > 37000:
            motor1.motorOn('sr', 10, 20)
        # move left if left IR sensor is over the line
        elif left > 36500:
            motor1.motorOn('sl', 10, 20)
        # go backwards if neither sensor is over the line
        else:
            motor1.motorOn('r', 18, 30)
    
    # if button is switched off
    elif not buttonPressed:
        motor1.motorOff()

        